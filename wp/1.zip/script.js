document.addEventListener('DOMContentLoaded', function() {
    var files = [
        { name: '文件1.txt', url: 'cs.txt', type: 'text/plain' },
        { name: '文件2.jpg', url: '1.jpg', type: 'image/jpeg' },
        { name: '文件3.gz', url: '1.zip', type: 'application/gzip' },
        // 更多文件...
    ];

    var fileList = document.getElementById('file-list');
    var previewContainer = document.getElementById('preview-container');
    var errorMessage = document.createElement('div');
    errorMessage.id = 'error-message';
    previewContainer.appendChild(errorMessage);

    files.forEach(function(file) {
        var li = document.createElement('li');
        li.textContent = file.name;
        li.onclick = function() {
            previewFile(file.url, file.type);
        };
        fileList.appendChild(li);
    });
});

async function previewFile(url, type) {
    var previewContainer = document.getElementById('preview-container');
    var errorMessage = document.getElementById('error-message');
    errorMessage.innerHTML = ''; // 清空之前的提示信息

    if (type === 'application/zip') {
        var zip = new JSZip();
        zip.loadAsync(url).then(function(zip) {
            zip.forEach(function(relativePath, zipEntry) {
                if (zipEntry.dir) {
                    // 忽略目录
                } else {
                    zipEntry.async('blob').then(function(blob) {
                        var blobUrl = URL.createObjectURL(blob);
                        var link = document.createElement('a');
                        link.href = blobUrl;
                        link.download = relativePath;
                        link.click();
                    });
                }
            });
        });
    } else if (type === 'application/gzip') {
        var blob = await fetch(url).then(function(response) {
            return response.blob();
        });
        var data = await blob.arrayBuffer();
        var inflated = pako.inflate(data);
        var text = new TextDecoder('utf-8').decode(inflated);
        var pre = document.createElement('pre');
        pre.textContent = text;
        previewContainer.appendChild(pre);
    } else if (type === 'text/plain') {
        var text = await fetch(url).then(function(response) {
            return response.text();
        });
        var pre = document.createElement('pre');
        pre.textContent = text;
        previewContainer.appendChild(pre);
    } else if (type === 'image/jpeg' || type === 'image/png' || type === 'image/gif') {
        var img = document.createElement('img');
        img.src = url;
        previewContainer.appendChild(img);
    } else if (type === 'application/pdf') {
        var iframe = document.createElement('iframe');
        iframe.src = url;
        previewContainer.appendChild(iframe);
    } else {
        errorMessage.innerHTML = '不支持的文件类型：' + type;
    }
}
